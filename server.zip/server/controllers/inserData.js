const asyncHandler = require("express-async-handler");
const Product = require("../models/product.js");
const data = require("../../data/ecommerce.json");
const slugify = require("slugify");
const categoryData = require("../../data/cate_brand.js");
const ProductCategory = require("../models/productCategory.js");

const fn = async (product) => {
  await Product.create({
    title: product?.name,
    slug: slugify(product?.name),
    description: product?.description1,
    brand: product?.brand,
    price: Math.round(Number(product?.price.match(/\d/g).join("")) / 100),
    category: product.category[1],
    quantity: Math.round(Math.random() * 1000),
    sold: Math.round(Math.random() * 100),
    images: product?.images,
    color: product?.variants?.find((el) => el.label === "Color")?.variants[0],
    thumbnail: product?.thumbnail,
    totalRatings: Math.round(Math.random() * 5),
  });
};

const fn2 = async (cate) => {
  await ProductCategory.create({
    title: cate?.cate,
    brand: cate?.brand,
  });
};

const insertData = asyncHandler(async (req, res) => {
  const promises = [];
  for (let product of data) promises.push(fn(product));
  await Promise.all(promises);
  return res.status(200).json("Done !!!");
});

const insertCategory = asyncHandler(async (req, res) => {
  const promises = [];
  for (let cate of categoryData) promises.push(fn2(cate));
  await Promise.all(promises);
  return res.status(200).json("Done !!!");
});

module.exports = { insertData, insertCategory };
