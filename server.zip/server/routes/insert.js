const router = require("express").Router();
const ctrls = require("../controllers/inserData.js");

router.post("/", ctrls.insertData);
router.post("/cate", ctrls.insertCategory);

module.exports = router;
